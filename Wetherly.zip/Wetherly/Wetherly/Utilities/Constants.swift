//
//  Constants.swift
//  Wetherly
//
//  Created by Rohan Sakhare on 26/06/24.
//

import Foundation

struct Constants {
    struct Keys {
        static let weatherAPIKey = "34254477a05fc221a51918050726d37a"
    }
}
