//
//  WetherlyApp.swift
//  Wetherly
//
//  Created by Rohan Sakhare on 26/06/24.
//

import SwiftUI

@main
struct WetherlyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
